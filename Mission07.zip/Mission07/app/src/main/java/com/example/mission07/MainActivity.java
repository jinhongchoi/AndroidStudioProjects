package com.example.mission07;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_MENU = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                startActivityForResult(intent, REQUEST_CODE_MENU);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // 위에 메서드에서 첫번째 파라미터는 액티비티를 띄울 때 전달했던 요청 코드와 같다. 이 값으로 어떤 액티비티로
        // 응답을 받은 것인지 구분할 수 있다.

        // 두번째 파라미터는 새 액티비티로부터 전달된 응답 코드 -> 보통 처리 결과가 정상인지 아닌지를 구분하는데 사용
        // 보통 result_ok 상수를 전달하는 방법으로 정상처리임을 알린다.

        // 세번째 액티비티는 새 액티비티로부터 전달 받은 인텐트 -> 새 액티비티의 데이터를 전달 할 수 있다.

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode ==REQUEST_CODE_MENU){

            if (resultCode == RESULT_OK){
                String name = data.getStringExtra("name");

                Toast.makeText(getApplicationContext(), "응답으로 전달된 name : " + name,
                        Toast.LENGTH_LONG).show();
            }
        }

    }

}