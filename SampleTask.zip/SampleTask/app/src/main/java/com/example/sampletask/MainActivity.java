package com.example.sampletask;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        // 버튼을 누를때마다 자기 자신이 뜸! -> 이게 사라지는게 아니라 계속 쌓이는 형태
        // 뒤로가기를 누르면 하나가 사라지는 것을 확인 할 수 있음!
        // Task -> 새로뜨는 화면을 차례대로 스택에 넣어서 관리 하는 것!

        // Manifest에 android:launchMode="singleTop" 이거 추가하면 한 번만 생성됨!

    }
}